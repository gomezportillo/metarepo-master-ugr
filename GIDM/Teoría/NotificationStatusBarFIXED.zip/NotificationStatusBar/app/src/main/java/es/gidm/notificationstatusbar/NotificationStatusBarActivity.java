package es.gidm.notificationstatusbar;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.NotificationChannel;
import android.content.Context;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class NotificationStatusBarActivity extends AppCompatActivity
{
    private int counter = 1;

    private String channel_title = "Notification channel";
    private String channel_description = "New notification";
    private String channel_id = "default";

    private static final int NOTI_PRIMARY = 1100;

//  private Uri sonidoURI = Uri
//          .parse("android.resource://es.gidm.notificationstatusbar/"
//                  + R.raw.ding);
//  private long[] patronVibracion = {0, 200, 200, 300};


    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // Check the android version
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
        {

            // Create channel
            Toast.makeText(getApplicationContext(), "Creating channel...", Toast.LENGTH_SHORT).show();

            NotificationChannel channel = new NotificationChannel(channel_id,
                    channel_title,
                    NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(channel_description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);

            // Set listener to the button
            findViewById(R.id.boton).setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    Notification.Builder nb = new Notification.Builder(getApplicationContext(), channel_id)
                            .setContentTitle("My Notification")
                            .setContentText("Notification number " + counter++)
                            .setSmallIcon(getSmallIcon())
                            .setAutoCancel(true);

                    NotificationManager notificationMgr = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

                    if (nb != null && notificationMgr != null)
                    {
                        notificationMgr.notify(NOTI_PRIMARY, nb.build());
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "ERROR. Something is null", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
        else
        {
            Toast.makeText(getApplicationContext(), "ERROR. API < 27", Toast.LENGTH_SHORT).show();
        }
    }

    private int getSmallIcon()
    {
        return android.R.drawable.stat_notify_chat;
    }
}